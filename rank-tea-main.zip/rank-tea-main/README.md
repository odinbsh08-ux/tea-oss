# rank-tea
 Asks you to compare two packages available via tea in terms of how important they are to FOSS
